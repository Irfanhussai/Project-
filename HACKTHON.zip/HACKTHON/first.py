import pandas as pd
import streamlit as st
import plotly.express as px
from PIL import Image


st.set_page_config(page_title='Drop out analysis')
st.header('SCHOOL WISE ANALYSIS')
st.subheader("Welcome to the analysis of dropout")

excel_file='data file.xlsx'

df=pd.read_excel(excel_file,
                 
                 usecols='A:F',
                 header=1)

st.dataframe(df)
pd.read_excel()