<?php
include 'dbconnect.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
    $code=$_POST['code'];
    $school=$_POST['school'];
$AREA=$_POST['area'];
$FACULITY=$_POST['FACULITY'];
$FACILITY=$_POST['FACILITY'];
$FAMILY=$_POST['FAMILY'];
$OTHERS=$_POST['OTHERS'];
$INSERT="INSERT INTO `review_data` (`code`,`SCHOOL`,`AREA_PROBLEM`,`Faculity`,`Facility`,`Family`,`others`)
                    VALUES('$code','$school','$AREA','$FACULITY','$FACILITY','$FAMILY','$OTHERS')";
$query=mysqli_query($con,$INSERT);
    if($query)
    {
       
        header('location:Index.php');
             
  }
    else
    {
        // die(MySQLi_connect_error());
        echo"data not Inserted<br>".mysqli_error($con);
    }
}

?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Review Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    <h1>Provide the Reasion of Drawback</h1>
<div class="container my-5"> 

<form method="POST">
<div class="mb-3">
<label >UDISE CODE</label>
    <input type="text" class="form-control" name="code" id="Name" >
  </div>
<label >School Name</label>
    <input type="text" class="form-control" name="school" id="Name" >
  </div>

    <label >AREA WISE PROBLEM</label>
    <input type="text" class="form-control" name="area" id="Name" >
  </div>
  <div class="mb-3">
    <label >FACULITY PROBLEM</label>
    <input type="text" class="form-control" name="FACULITY" id="Name" >
  </div>
  <div class="mb-3">
    <label >FACILITY PROBLEM</label>
    <input type="text" class="form-control" name="FACILITY" id="Name" >
  </div>
  <div class="mb-3">
    <label >FAMILY PROBLEM</label>
    <input type="text" class="form-control" name="FAMILY" id="FName" >
  </div>
  <div class="mb-3">
    <label >OTHER PROBLEM</label>
    <input type="text" class="form-control" name="OTHERS" id="MName" >
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>


</div>
          
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" ></script>
  </body>
</html>