<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style1.css">
    <title>Dropout Analysis</title>
    
    </style>
</head>
<body>
    <header>
        <h1>Right to Education and Dropout Analysis</h1>
    </header>
    <header>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="container-fluid">
 
      <a class="navbar-brand" href="#">
      <img src="/IMAGES/LOGO.png" alt="LOGO" width="40" height="24">
      </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>

        
        <li class="nav-item">
          <a class="nav-link" href="SCHOOL ANALYSIS.php">SCHOOL WISE ANALYSIS</a>
        </li>
    
        <li class="nav-item">
          <a class="nav-link" href="#">AREA WISE ANALYSIS</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">CAST WISE ANALYSIS</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">AGE WISE ANALYSIS</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

    </nav>
    <section id="school-wise">
        <h2>School Wise Analysis</h2>
        <p>Information and analysis related to dropout rates based on schools.</p>

        <table>
            <thead>
                <tr>
                    <th>Serial No</th>
                    <th>Name</th>
                    <th>State</th>
                    <th>Last Year</th>
                    <th>This Year</th>
                    <th>Total Students</th>
                    <th>Reason for Remaining</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>John Doe</td>
                    <td>New York</td>
                    <td>100</td>
                    <td>90</td>
                    <td>190</td>
                    <td>Financial Constraints</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Jane Smith</td>
                    <td>California</td>
                    <td>150</td>
                    <td>140</td>
                    <td>290</td>
                    <td>Family Issues</td>
                </tr>
        
            </tbody>
        </table>
        <!--  -->

        <html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Work',     11],
          ['Eat',      2],
          ['Commute',  2],
          ['Watch TV', 2],
          ['Sleep',    7]
        ]);

        var options = {
          title: 'My Daily Activities'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="piechart" style="width: 900px; height: 500px;"></div>
  </body>
</html>

        <!--  -->

    </section>
    <section id="area-wise">
        <h2>Area Wise Analysis</h2>
        <p>Information and analysis related to dropout rates based on areas.</p>
    </section>
    <section id="gender-wise">
        <h2>Gender Wise Analysis</h2>
        <p>Information and analysis related to dropout rates based on gender.</p>
    </section>
    <section id="caste-wise">
        <h2>Caste Wise Analysis</h2>
        <p>Information and analysis related to dropout rates based on caste.</p>
    </section>
    <section id="age-wise">
        <h2>Age/Standard Wise Analysis</h2>
        <p>Information and analysis related to dropout rates based on age/standard.</p>
    </section>
    <footer>
        <p>&copy; 2024 Dropout Analysis - All rights reserved.</p>
    </footer>
</body>
</html>