<!DOCTYPE html>
<html>
<head>
    <title>State and District Dropdown</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
   
   <style>
        /* Basic Styling */
        body {
            padding: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-group">
            <label for="state">State:</label>
            <select id="state" class="form-control" onchange="populateDistricts()">
                <option value="">Select State</option>
                <!-- Add your states here -->
                <option value="DELHI">DELHI</option>
                <option value="MAHARASHTRA">MAHARASHTRA</option>
                <option value="KARNATAKA">KARNATAKA</option>
                <option value="KERLA">KERLA</option>
                <option value="MADHYA PARDESH">MADHYA PARDESH</option>
                <option value="PUNJAB">PUNJAB</option>
                <option value="ANDRA">ANDRA</option>
                <option value="JK">JAMMU AND KASHMIR</option>
            </select>
        </div>
        <div class="form-group">
            <label for="district">District:</label>
            <select id="district" class="form-control">
                <option value="">Select District</option>
            </select>
        </div>
    </div>

    <script>
        function populateDistricts() {
            var state = document.getElementById("state").value;
            var districtDropdown = document.getElementById("district");
            districtDropdown.innerHTML = "";
            if (state === "DELHI") {
                // Populate districts for State 1
                addDistrictOption("district1", "Central Delhi")
                {
                    
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Work',     11],
          ['Eat',      2],
          ['Commute',  2],
          ['Watch TV', 2],
          ['Sleep',    7]
        ]);

        var options = {
          title: 'My Daily Activities',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    
                addDistrictOption("district2", "East Delhi");
                addDistrictOption("district3", "New Delhi");
                addDistrictOption("district4", "West Delhi");
            } else if (state === "KARNATAKA") {
                // Populate districts for State 2
                addDistrictOption("district5", "Belgavi");
                addDistrictOption("district6", "Banglore");
                addDistrictOption("district7", "Gadag");

            } else if (state === "MAHARASHTRA") {
                // Populate districts for State 3
                addDistrictOption("district8", "Pune");
                addDistrictOption("district9", "Kolapur");
                addDistrictOption("district10", "Satara");
                addDistrictOption("district11", "Sangli");
                addDistrictOption("district12", "Mumbai");
            }
            else if (state === "MADHYA PARDESH") {
                // Populate districts for State 3
                addDistrictOption("district13", "Bhopal");
                addDistrictOption("district14", "Gawlaior");
                addDistrictOption("district15", "Indoor");
              
            }
            else if (state === "JK") {
                // Populate districts for State 3
                addDistrictOption("district13", "Srinagar");
                addDistrictOption("district14", "Jammu");
                addDistrictOption("district15", "Budgam");
                addDistrictOption("district13", "Baramulla");
                addDistrictOption("district14", "Shopian");
                addDistrictOption("district15", "Rajouri");
              
            }
        }

        function addDistrictOption(value, text) {
            var districtDropdown = document.getElementById("district");
            var option = document.createElement("option");
            option.value = value;
            option.text = text;
            districtDropdown.appendChild(option);
        }
    </script>
     <body>
    <div id="piechart_3d" style="width: 900px; height: 500px;"></div>
  </body>
</body>
</html>


<!--  -->

  
<!--  -->