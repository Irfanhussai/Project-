<?php
include 'dbconnect.php';

if($_SERVER['REQUEST_METHOD']=='POST'){

$NAME=$_POST['name'];
$PASSWORD=$_POST['password'];


$INSERT="INSERT INTO `login_page` (`USER_NAME`,`PASSWORD`)
                    VALUES('$NAME','$PASSWORD')";
$query=mysqli_query($con,$INSERT);
    if($query)
    {
        header('location:Admin.php');
        
      
  }
    else
    {
        // die(MySQLi_connect_error());
        echo"data not Inserted<br>".mysqli_error($con);
    }
}

?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LOGIN PAGE </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>

  </style>
  
  </head>
  <body>
    <!-- <h1>LOGIN PAGE</h1>
<div class="container my-5">  -->

<!-- <form method="POST">
  <div class="mb-3">
    <label >USER NAME</label>
    <input type="text" class="form-control" name="name" id="Name" >
  </div>
  <div class="mb-3">
    <label >PASSWORD</label>
    <input type="text" class="form-control" name="password" id="FName" >
  </div>
  
  <button type="submit" class="btn btn-primary">LOGIN</button>
</form> -->
<form method="POST">
<div class="container">
  <h1 class="text-center">Login</h1>
    <div class="form-group">
      <label for="username">Username</label>
      <input type="text" class="form-control" id="name" name="name" placeholder="Enter username">
    </div>
    <div class="form-group">
      <label for="password">Password</label>
      <input type="password" class="form-control" name="password" id="password" placeholder="Password">
    </div>
    <button type="submit" class="btn btn-primary btn-block">Login</button>
  </form>

</div>
          







    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" ></script>
  </body>
</html>