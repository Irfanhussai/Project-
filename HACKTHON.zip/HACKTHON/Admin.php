<?php
include 'dbconnect.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
$ADHAR=$_POST['adhar'];
$NAME=$_POST['name'];
$DOB=$_POST['dob'];
$FNAME=$_POST['fname'];
$MNAME=$_POST['mname'];
$INSERT="INSERT INTO `admin` (`Adhar Number`,`NAME`,`DOB`,`FNAME`,`MNAME`)
                    VALUES('$ADHAR','$NAME','$DOB','$FNAME','$MNAME')";
$query=mysqli_query($con,$INSERT);
    if($query)
    {
        header('location:Analysis.php');
             
  }
    else
    {
        // die(MySQLi_connect_error());
        echo"data not Inserted<br>".mysqli_error($con);
    }
}

?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ADMIN PAGE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    <h1>Submit Student details</h1>
<div class="container my-5"> 

<form method="POST">
<div class="mb-3">
    <label >ADHAR NUMBER</label>
    <input type="text" class="form-control" name="adhar" id="Name" >
  </div>
  <div class="mb-3">
    <label >NAME</label>
    <input type="text" class="form-control" name="name" id="Name" >
  </div>
  <div class="mb-3">
    <label >DOB</label>
    <input type="text" class="form-control" name="dob" id="Name" >
  </div>
  <div class="mb-3">
    <label >FATHERS NAME</label>
    <input type="text" class="form-control" name="fname" id="FName" >
  </div>
  <div class="mb-3">
    <label >MOTHERS NAME</label>
    <input type="text" class="form-control" name="mname" id="MName" >
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>


</div>
          
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" ></script>
  </body>
</html>