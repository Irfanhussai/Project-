<?php
    $con=MySQLi_connect('localhost','root','','hackthon');
if(!$con){
    die(MySQLi_connect_error($con));
}
// else{
//     echo'connection sucessfull';
// }
?>