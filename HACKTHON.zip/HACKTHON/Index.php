<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style1.css">
    <title>Dropout Analysis</title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

</head>
<header>
	</head>
	    <div class="navbar navbar-default">
	    	<div class="container-fluid">
	    		<div class="navbar-header">
	    			 <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapibleMenu">
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				      </button>
	    			<a href="#" class="navbar-brand">STUDENT DROPOUT ANALYSIS</a>
	    		</div>
	    		<div class="collapse navbar-collapse" id="collapibleMenu">
	    			<ul class="nav navbar-nav navbar-right">
				        <li><a href="#">Home</a></li>
				        <li><a href="#">About us</a></li>
				        <li><a href="Login.php">ADMIN PORTAL</a></li>
				        <!-- <li><a href="Analysis.php"></a></li>
                <li><a href="solution.php"></a></li> -->
				    </ul>
				   
	    		</div>
	    	</div>
	    </div>
</header>
<body>

    <section id="school-wise">
        <h2>STATE WISE DROPOUT ANALYSIS</h2>
        <p>Information and analysis related to dropout rates based on different area</p>
        <!--  -->
        <div class="container">
        <h1>State and City </h1>
        <div class="form-group">
            <label for="states">Select a State:</label>
            <select id="states" class="form-control" onchange="loadCities(this.value)">
                <option value="DELHI">DELHI</option>
                <option value="MAHARASHTRA">MAHARASHTRA</option>
                <option value="KARNATAKA">KARNATAKA</option>
                <option value="KERLA">KERLA</option>
                <option value="MADHYA PARDESH">MADHYA PARDESH</option>
                <option value="PUNJAB">PUNJAB</option>
                <option value="ANDRA">ANDRA</option>
                <option value="JK">JAMMU AND KASHMIR</option>
                
                <!-- Add more states as needed -->
            </select>
        </div>

        <div id="citiesContainer" class="form-group">
            <label for="cities">Select a City:</label>
            <select id="cities" class="form-control">
                <option value="">Select a City</option>
            </select>
            <canvas id="cityChart" width="30" height="20"></canvas>
        </div>
    </div>

    <script>
        function loadCities(state) {
            const cities = getCitiesForState(state); // Assume this function retrieves cities for a given state
            const citiesDropdown = document.getElementById("cities");
            citiesDropdown.innerHTML = '<option value="">Select a City</option>';
            cities.forEach(city => {
                const option = document.createElement("option");
                option.text = city;
                option.value = city;
                citiesDropdown.add(option);
            });
        }

        function getCitiesForState(state) {
            // This is a placeholder function, in a real application this data would come from a database or API
            if (state === "DELHI") {
                return ["NEW DELHI", "WEST DELHI", "ALIPUR"];
            } else if (state === "JK") {
                return ["SRINAGAR", "JAMMU", "BARAMULA","BUDGAM"];
            } else if (state === "MAHARASHTRA") {
                return ["MUMBAI", "PUNE", "SATARA","SANGLI"];
            } else if (state === "PUNJAB") {
                return ["AMRITSAR", "BARNALA", "BATHINDA","FARIDKOT"];
            } else if (state === "KARNATAKA") {
                return ["BELGAVI", "BANGLORE", "GADAG","HUBBLI"];
            } 
            else {
                return [];
            }
        }

        function generateGraph(city) {
            // Assume this function generates a graph for the given city
            const ctx = document.getElementById('cityChart').getContext('2d');
            new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
                    datasets: [{
                        label: `Sales Data for ${city}`,
                        data: [65, 59, 80, 81, 56, 55, 40],
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        borderColor: 'rgba(255, 0, 132, 1)',
                        borderWidth: 1,
                      
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        document.getElementById('cities').addEventListener('change', function () {
            const selectedCity = this.value;
            if (selectedCity) {
                generateGraph(selectedCity);
            }
        });
    </script>
<!--  -->
    <div class="body">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['STATE', 'Drop Ration per Anrolement'],
          ['Andamen and Nicobar',     5],
          ['Andra Pardesh',      16.3],
          ['Arunchal Paardesh',  11.7],
          ['Aasam', 20.3],
          ['Bihar',    20.5],
          ['Chandigarh', 20.5], 
          ['Chhattisgarh',    9.7],
          ['Goa', 9], 
          ['Gujarat', 17.9], 
          ['Haryana',    7],
          ['Himachal Pradesh', 1.5], 
          ['Jammu and Kashmi',    6], 
          ['Jharkhand', 2], 
          ['Karnataka',    14.7],
          ['Kerala', 5.5],
          ['Ladakh',4.9],
          ['Madhya Pardesh',10.1], 
          ['Maharashtra',10.7],
          ['Manipur',1.3],
          ['Meghalaya',21.7],
          ['Mizoram',11.9],
          ['Nagaland',17.5],
          ['Odisha',27.3],
          ['Punjab',17.2],
          ['Rajasthan',7.7],
          ['Sikkim',11.9],
          ['Tamil Nadu',4.5],
          ['Telangana',13.7],
          ['Uttar Pardesh',9.7],
          ['West Bengal',18]
    
        ]);

        var options = {
          title: 'State Wise Analysis Of Dropout Data'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
    </div>
    </div>
  </head>
    </section>
    
  <body>
    <div id="piechart" style="width: 900px; height: 500px;"></div>
        <!--  -->
        <div class="section" style="background-image: url('background.jpg');">
   

        <!--  -->
        <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Work',     11],
          ['Eat',      2],
          ['Commute',  2],
          ['Watch TV', 2],
          ['Sleep',    7]
        ]);

        var options = {
          title: 'My Daily Activities',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>
        <!--  -->
    <!--Table and divs that hold the pie charts-->  
    <footer>
        <p>&copy; 2024 Dropout Analysis - All rights reserved.</p>
    </footer>
</body>
</html>
	<!-- Bootstrap -->
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>